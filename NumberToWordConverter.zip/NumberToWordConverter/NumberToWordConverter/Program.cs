﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberToWordConverter
{
	class Program
	{
		static void Main(string[] args)
		{
			string isNegative = "";
			
			try
			{
				Console.WriteLine("Enter a Number to convert");

				string number = Console.ReadLine();
				int num = -1;
				number = Convert.ToInt32(number).ToString();
				if (number.Length > 9)
				{
					Console.WriteLine(" \nEnter max 9 digit length ");
					Console.ReadLine();
				}
				if (!int.TryParse(number, out num))
				{
					Console.WriteLine("Not an integer");
					Console.ReadLine();
				}

			
				else
				{

					if (number.Contains("-"))
					{
						isNegative = "Minus ";
						number = number.Substring(1, number.Length - 1);
					}

					if (number == "0")
					{
						Console.WriteLine(" \nZero ");
					}
					else
					{
						Console.WriteLine(" \n{0}", isNegative + ConvertToWords(number));


					}
				}
				Console.ReadKey();
			}
			catch (Exception ex)
			{

				Console.WriteLine(ex.Message);
			}

		}


		private static String ConvertToWords(String numb)
		{
			String val = "", wholeNo = numb;
			
			try
			{
				
				val = String.Format("{0}", ConvertWholeNumber(wholeNo).Trim());
			}
			catch { }
			return val;
		}
		private static String ConvertWholeNumber(String Number)
		{
			string word = "";
			try
			{
				bool beginsZero = false;
				bool isDone = false;
				double dblAmt = (Convert.ToDouble(Number));
				
				if (dblAmt > 0)
				{
					beginsZero = Number.StartsWith("0");

					int numDigits = Number.Length;
					int pos = 0;
					String place = "";
					switch (numDigits)
					{
						case 1:

							word = ones(Number);
							isDone = true;
							break;
						case 2:
							word = tens(Number);
							isDone = true;
							break;
						case 3:
							pos = (numDigits % 3) + 1;
							place = " hundred and  ";
							break;
						case 4:
						case 5:
						case 6:
							pos = (numDigits % 4) + 1;
							place = " thousand ";
							break;
						case 7:
						case 8:
						case 9:
							pos = (numDigits % 7) + 1;
							place = " million ";
							break;
						case 10:
						case 11:
						case 12:

							pos = (numDigits % 10) + 1;
							place = " billion ";
							break;
						 
						default:
							isDone = true;
							break;
					}
					if (!isDone)
					{
						if (Number.Substring(0, pos) != "0" && Number.Substring(pos) != "0")
						{
							try
							{
								word = ConvertWholeNumber(Number.Substring(0, pos)) + place + ConvertWholeNumber(Number.Substring(pos));
							}
							catch { }
						}
						else
						{
							word = ConvertWholeNumber(Number.Substring(0, pos)) + ConvertWholeNumber(Number.Substring(pos));
						}

						
					}
					
					if (word.Trim().Equals(place.Trim())) word = "";
				}
			}
			catch { }
			return word.Trim();
		}

		private static String tens(String Number)
		{
			int _Number = Convert.ToInt32(Number);
			String name = null;
			switch (_Number)
			{
				case 10:
					name = "ten";
					break;
				case 11:
					name = "eleven";
					break;
				case 12:
					name = "twelve";
					break;
				case 13:
					name = "thirteen";
					break;
				case 14:
					name = "fourteen";
					break;
				case 15:
					name = "fifteen";
					break;
				case 16:
					name = "sixteen";
					break;
				case 17:
					name = "seventeen";
					break;
				case 18:
					name = "eighteen";
					break;
				case 19:
					name = "nineteen";
					break;
				case 20:
					name = "twenty";
					break;
				case 30:
					name = "thirty";
					break;
				case 40:
					name = "fourty";
					break;
				case 50:
					name = "fifty";
					break;
				case 60:
					name = "sixty";
					break;
				case 70:
					name = "seventy";
					break;
				case 80:
					name = "eighty";
					break;
				case 90:
					name = "ninety";
					break;
				default:
					if (_Number > 0)
					{
						name = tens(Number.Substring(0, 1) + "0") + " " + ones(Number.Substring(1));
					}
					break;
			}
			return name;
		}
		private static String ones(String Number)
		{
			int _Number = Convert.ToInt32(Number);
			String name = "";
			switch (_Number)
			{

				case 1:
					name = "one";
					break;
				case 2:
					name = "two";
					break;
				case 3:
					name = "three";
					break;
				case 4:
					name = "four";
					break;
				case 5:
					name = "five";
					break;
				case 6:
					name = "six";
					break;
				case 7:
					name = "seven";
					break;
				case 8:
					name = "eight";
					break;
				case 9:
					name = "nine";
					break;
			}
			return name;
		}

		
	}
}
